from . import pos_setting
from . import product_pos