# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    "name": "Multiple Images POS",
    "version": "17.0.1.0.0",
    "category": "Sale",
    "sequence": 15,
    "summary": "Track Changes to Unit Price on Purchase Orders.",
    "website": "https://www.odoo.com/app/crm",
    "depends": ["point_of_sale"],
    "data": [
        'views/pos_setting_views.xml',
        'views/product_pos_views.xml',
    ],
    "assets": {
        # Assets
        'point_of_sale._assets_pos': [
            'multiple_img_pos/static/src/xml/icon.xml',
            'multiple_img_pos/static/src/scss/style.scss',
        ],
    },

        # 'assets': {
        #     'point_of_sale._assets_pos': [
        #         'multi_image_pos/static/src/xml/icon.xml',
        #         # 'multi_image_pos/static/src/xml/image_popup.xml',
        #         # 'multi_image_pos/static/src/js/icon.js',
        #         # 'multi_image_pos/static/src/js/image_popup.js',
        #
        #     ],
        # },
        "installable": True,
        "application": True,
        "license": "LGPL-3",
    }
