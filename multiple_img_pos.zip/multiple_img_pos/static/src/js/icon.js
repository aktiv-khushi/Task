/** @odoo-module **/
import { ProductCard } from "@point_of_sale/app/generic_components/product_card/product_card";
import { patch } from "@web/core/utils/patch";
//import { MultiImagePopup } from "./MultiImagePopup"
import { onMounted } from "@odoo/owl";
//Patching ProductCard component
console.log("\n\n\n11111111111111111111")

patch(ProductCard.prototype, {
   async setup(){
       super.setup(...arguments);
       onMounted(this.loadProductData)
   },

   async onClickImageIcon() {

   }

//export class image extends ProductCard {
//
//    static template = "multiple_img_pos.ProductCard";
//    static components = { ProductCard };
//    console.log("\n\n\n2222222222222222")
//    setup() {
//        super.setup();
//        });
//    }
//    }
